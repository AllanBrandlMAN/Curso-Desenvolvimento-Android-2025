package com.allanbrandl.handsonktappclockdigital

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextClock
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private var tv_updateClock : TextView? = null
    private var tc_12horas : TextClock? = null
    private var tc_24horas : TextClock? = null
    private var button : Button? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        iniciarComponentes();


    }

    private fun iniciarComponentes() {

        tv_updateClock = findViewById(R.id.tv_updateClock)
        tc_12horas = findViewById(R.id.tc_12horas)
        tc_24horas = findViewById(R.id.tc_24horas)
        button = findViewById(R.id.button)

    }

    fun AtualizarHoraAtual(view: View) {
        tv_updateClock!!.setText("Hora " + tc_24horas!!.getText())

    }

}